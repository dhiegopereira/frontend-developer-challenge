const show = (req, res) => { 
    res.render('index')
}

module.exports = {
    show
}